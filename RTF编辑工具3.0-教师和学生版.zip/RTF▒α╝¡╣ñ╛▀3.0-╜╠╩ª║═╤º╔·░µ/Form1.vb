﻿Public Class Form1
    Private Sub 退出ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 退出ToolStripMenuItem.Click
        Dim a = MsgBox("您的文档尚未保存，确实要退出吗？", vbYesNoCancel + vbQuestion, "提示")
        If a = vbNo And RichTextBox1.Text <> "" Then
            SaveFileDialog1.ShowDialog()
            RichTextBox1.SaveFile(SaveFileDialog1.FileName)
            End
        ElseIf a = vbYes Then
            End
        ElseIf a = vbCancel Then
            Me.Show()
        End If
    End Sub

    Private Sub 打印ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 打印ToolStripMenuItem.Click
        MsgBox("功能未开发", vbNo, "-_-|||")
    End Sub

    Private Sub 打开ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 打开ToolStripMenuItem.Click
        OpenFileDialog1.ShowDialog()
        RichTextBox1.LoadFile(OpenFileDialog1.FileName)
    End Sub

    Private Sub 保存ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 保存ToolStripMenuItem.Click
        SaveFileDialog1.ShowDialog()
        RichTextBox1.SaveFile(SaveFileDialog1.FileName)
    End Sub

    Private Sub 关闭当前打开的文档新建ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 关闭当前打开的文档新建ToolStripMenuItem.Click
        RichTextBox1.Text = ""
    End Sub

    Private Sub 清空ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 清空ToolStripMenuItem.Click
        RichTextBox1.Clear()
    End Sub

    Private Sub 颜色ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 颜色ToolStripMenuItem.Click
        ColorDialog1.ShowDialog()
        RichTextBox1.SelectionColor = ColorDialog1.Color
    End Sub

    Private Sub 字体ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 字体ToolStripMenuItem.Click
        FontDialog1.ShowDialog()
        RichTextBox1.SelectionFont = FontDialog1.Font
    End Sub

    Private Sub 剪切ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 剪切ToolStripMenuItem.Click
        RichTextBox1.Cut()
    End Sub

    Private Sub 复制ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 复制ToolStripMenuItem.Click
        RichTextBox1.Copy()
    End Sub

    Private Sub 粘贴ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 粘贴ToolStripMenuItem.Click
        RichTextBox1.Paste()
    End Sub


    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub 插入准确时间ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 插入准确时间ToolStripMenuItem.Click
        RichTextBox1.Text += Now
    End Sub

    Private Sub 关于ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 关于ToolStripMenuItem.Click
        AboutBox1.Show()
    End Sub
End Class
