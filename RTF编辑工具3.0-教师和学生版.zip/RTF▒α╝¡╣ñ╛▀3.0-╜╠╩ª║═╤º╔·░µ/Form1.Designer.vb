﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.文件ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.打开ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.保存ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.关闭当前打开的文档新建ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.打印ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.退出ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.编辑ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.清空ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.颜色ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.字体ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.剪切ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.复制ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.粘贴ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.应用ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.日历ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.插入准确时间ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.关于ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.激活此RTF编辑工具副本ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.教师和学生版无需激活ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(12, 39)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(2131, 1480)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = ""
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(28, 28)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.文件ToolStripMenuItem, Me.编辑ToolStripMenuItem, Me.应用ToolStripMenuItem, Me.ToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(2155, 37)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        '文件ToolStripMenuItem
        '
        Me.文件ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.打开ToolStripMenuItem, Me.保存ToolStripMenuItem, Me.ToolStripSeparator1, Me.关闭当前打开的文档新建ToolStripMenuItem, Me.打印ToolStripMenuItem, Me.ToolStripSeparator2, Me.退出ToolStripMenuItem})
        Me.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem"
        Me.文件ToolStripMenuItem.Size = New System.Drawing.Size(72, 33)
        Me.文件ToolStripMenuItem.Text = "文件"
        '
        '打开ToolStripMenuItem
        '
        Me.打开ToolStripMenuItem.Image = CType(resources.GetObject("打开ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.打开ToolStripMenuItem.Name = "打开ToolStripMenuItem"
        Me.打开ToolStripMenuItem.Size = New System.Drawing.Size(591, 40)
        Me.打开ToolStripMenuItem.Text = "打开"
        '
        '保存ToolStripMenuItem
        '
        Me.保存ToolStripMenuItem.Image = CType(resources.GetObject("保存ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.保存ToolStripMenuItem.Name = "保存ToolStripMenuItem"
        Me.保存ToolStripMenuItem.Size = New System.Drawing.Size(591, 40)
        Me.保存ToolStripMenuItem.Text = "保存"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(588, 6)
        '
        '关闭当前打开的文档新建ToolStripMenuItem
        '
        Me.关闭当前打开的文档新建ToolStripMenuItem.Image = CType(resources.GetObject("关闭当前打开的文档新建ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.关闭当前打开的文档新建ToolStripMenuItem.Name = "关闭当前打开的文档新建ToolStripMenuItem"
        Me.关闭当前打开的文档新建ToolStripMenuItem.Size = New System.Drawing.Size(591, 40)
        Me.关闭当前打开的文档新建ToolStripMenuItem.Text = "关闭当前打开的文档（新建）（此操作不可撤销）"
        '
        '打印ToolStripMenuItem
        '
        Me.打印ToolStripMenuItem.Image = CType(resources.GetObject("打印ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.打印ToolStripMenuItem.Name = "打印ToolStripMenuItem"
        Me.打印ToolStripMenuItem.Size = New System.Drawing.Size(591, 40)
        Me.打印ToolStripMenuItem.Text = "打印"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(588, 6)
        '
        '退出ToolStripMenuItem
        '
        Me.退出ToolStripMenuItem.Image = CType(resources.GetObject("退出ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem"
        Me.退出ToolStripMenuItem.Size = New System.Drawing.Size(591, 40)
        Me.退出ToolStripMenuItem.Text = "退出"
        '
        '编辑ToolStripMenuItem
        '
        Me.编辑ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.清空ToolStripMenuItem, Me.颜色ToolStripMenuItem, Me.字体ToolStripMenuItem, Me.ToolStripSeparator3, Me.剪切ToolStripMenuItem, Me.复制ToolStripMenuItem, Me.粘贴ToolStripMenuItem})
        Me.编辑ToolStripMenuItem.Name = "编辑ToolStripMenuItem"
        Me.编辑ToolStripMenuItem.Size = New System.Drawing.Size(72, 33)
        Me.编辑ToolStripMenuItem.Text = "编辑"
        '
        '清空ToolStripMenuItem
        '
        Me.清空ToolStripMenuItem.Image = CType(resources.GetObject("清空ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.清空ToolStripMenuItem.Name = "清空ToolStripMenuItem"
        Me.清空ToolStripMenuItem.Size = New System.Drawing.Size(171, 40)
        Me.清空ToolStripMenuItem.Text = "清空"
        '
        '颜色ToolStripMenuItem
        '
        Me.颜色ToolStripMenuItem.Image = CType(resources.GetObject("颜色ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.颜色ToolStripMenuItem.Name = "颜色ToolStripMenuItem"
        Me.颜色ToolStripMenuItem.Size = New System.Drawing.Size(171, 40)
        Me.颜色ToolStripMenuItem.Text = "颜色"
        '
        '字体ToolStripMenuItem
        '
        Me.字体ToolStripMenuItem.Image = CType(resources.GetObject("字体ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.字体ToolStripMenuItem.Name = "字体ToolStripMenuItem"
        Me.字体ToolStripMenuItem.Size = New System.Drawing.Size(171, 40)
        Me.字体ToolStripMenuItem.Text = "字体"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(168, 6)
        '
        '剪切ToolStripMenuItem
        '
        Me.剪切ToolStripMenuItem.Image = CType(resources.GetObject("剪切ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.剪切ToolStripMenuItem.Name = "剪切ToolStripMenuItem"
        Me.剪切ToolStripMenuItem.Size = New System.Drawing.Size(171, 40)
        Me.剪切ToolStripMenuItem.Text = "剪切"
        '
        '复制ToolStripMenuItem
        '
        Me.复制ToolStripMenuItem.Image = CType(resources.GetObject("复制ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.复制ToolStripMenuItem.Name = "复制ToolStripMenuItem"
        Me.复制ToolStripMenuItem.Size = New System.Drawing.Size(171, 40)
        Me.复制ToolStripMenuItem.Text = "复制"
        '
        '粘贴ToolStripMenuItem
        '
        Me.粘贴ToolStripMenuItem.Image = CType(resources.GetObject("粘贴ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.粘贴ToolStripMenuItem.Name = "粘贴ToolStripMenuItem"
        Me.粘贴ToolStripMenuItem.Size = New System.Drawing.Size(171, 40)
        Me.粘贴ToolStripMenuItem.Text = "粘贴"
        '
        '应用ToolStripMenuItem
        '
        Me.应用ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.日历ToolStripMenuItem})
        Me.应用ToolStripMenuItem.Name = "应用ToolStripMenuItem"
        Me.应用ToolStripMenuItem.Size = New System.Drawing.Size(72, 32)
        Me.应用ToolStripMenuItem.Text = "应用"
        '
        '日历ToolStripMenuItem
        '
        Me.日历ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.插入准确时间ToolStripMenuItem})
        Me.日历ToolStripMenuItem.Name = "日历ToolStripMenuItem"
        Me.日历ToolStripMenuItem.Size = New System.Drawing.Size(315, 40)
        Me.日历ToolStripMenuItem.Text = "日历"
        '
        '插入准确时间ToolStripMenuItem
        '
        Me.插入准确时间ToolStripMenuItem.Name = "插入准确时间ToolStripMenuItem"
        Me.插入准确时间ToolStripMenuItem.Size = New System.Drawing.Size(315, 40)
        Me.插入准确时间ToolStripMenuItem.Text = "插入准确时间"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.关于ToolStripMenuItem, Me.ToolStripSeparator4, Me.激活此RTF编辑工具副本ToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(40, 33)
        Me.ToolStripMenuItem1.Text = "?"
        '
        '关于ToolStripMenuItem
        '
        Me.关于ToolStripMenuItem.Image = CType(resources.GetObject("关于ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem"
        Me.关于ToolStripMenuItem.Size = New System.Drawing.Size(367, 40)
        Me.关于ToolStripMenuItem.Text = "关于.."
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.Filter = "RTF|*.rtf"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "RTF|*.rtf"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.ImageScalingSize = New System.Drawing.Size(28, 28)
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(61, 4)
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(364, 6)
        '
        '激活此RTF编辑工具副本ToolStripMenuItem
        '
        Me.激活此RTF编辑工具副本ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.教师和学生版无需激活ToolStripMenuItem})
        Me.激活此RTF编辑工具副本ToolStripMenuItem.Image = CType(resources.GetObject("激活此RTF编辑工具副本ToolStripMenuItem.Image"), System.Drawing.Image)
        Me.激活此RTF编辑工具副本ToolStripMenuItem.Name = "激活此RTF编辑工具副本ToolStripMenuItem"
        Me.激活此RTF编辑工具副本ToolStripMenuItem.Size = New System.Drawing.Size(367, 40)
        Me.激活此RTF编辑工具副本ToolStripMenuItem.Text = "激活此 RTF编辑工具 副本"
        '
        '教师和学生版无需激活ToolStripMenuItem
        '
        Me.教师和学生版无需激活ToolStripMenuItem.Name = "教师和学生版无需激活ToolStripMenuItem"
        Me.教师和学生版无需激活ToolStripMenuItem.Size = New System.Drawing.Size(339, 40)
        Me.教师和学生版无需激活ToolStripMenuItem.Text = "教师和学生版无需激活"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(13.0!, 28.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(2155, 1531)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "RTF编辑工具3.0"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents 文件ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 打开ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 编辑ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents 保存ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents 关闭当前打开的文档新建ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 打印ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents 退出ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents 清空ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 颜色ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 字体ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 剪切ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 复制ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 粘贴ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents 关于ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents FontDialog1 As FontDialog
    Friend WithEvents ContextMenuStrip1 As ContextMenuStrip
    Friend WithEvents 应用ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 日历ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 插入准确时间ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents 激活此RTF编辑工具副本ToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents 教师和学生版无需激活ToolStripMenuItem As ToolStripMenuItem
End Class
